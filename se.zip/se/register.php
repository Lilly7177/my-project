
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "register";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];
    if (strlen($password) < 6) {
        echo '<script>alert("Password is too short. Please enter a password with at least 6 characters.")</script>';
    }
    else{
    $sql = "INSERT INTO users (email, password) VALUES (?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $password_hash);

    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    if ($stmt->execute()) {
        echo "Registration successful!";
        header("Location: ./login.html");
    } else {
        echo "Error: " . $stmt->error;
    }
    
    $stmt->close();
}
}
$conn->close();
?>
