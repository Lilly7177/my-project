-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 06, 2024 at 06:57 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se`
--

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `user name` varchar(100) NOT NULL,
  `vehicle num` varchar(100) NOT NULL,
  `mobile num` bigint(100) NOT NULL,
  `vehicle type` int(100) NOT NULL,
  `entry` datetime(6) NOT NULL,
  `exit` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `user name`, `vehicle num`, `mobile num`, `vehicle type`, `entry`, `exit`) VALUES
(1, 'chinni', 'ap517', 9959927844, 2, '2023-12-07 10:48:21.003420', '2023-12-07 11:04:39.117255'),
(2, 'prameela', 'ap1234', 9618414956, 2, '2023-11-30 19:45:25.495114', '2023-12-07 11:04:45.225528'),
(56, 'pramee', 'ap517', 9618414956, 4, '2023-11-27 14:49:21.000000', '2023-12-07 11:04:51.485164'),
(1, 'mammu', 'ap517', 8198730990, 2, '2023-12-07 11:06:09.384417', '2023-12-07 11:06:15.946165'),
(1, 'mamu', 'ap517', 9959927844, 2, '2023-12-07 11:07:21.812674', '2023-12-07 11:07:32.298960'),
(17, 'pramee', 'ap517', 9618414956, 4, '2023-12-06 11:50:02.149332', '2023-12-07 11:07:48.337766'),
(1, 'raji', 'ap517', 9959927844, 2, '2023-12-07 13:51:34.188754', '2023-12-07 13:52:42.974166'),
(1, 'pavani', 'ap2323', 9959927844, 2, '2023-12-12 13:49:16.982250', '2023-12-12 13:49:34.605520'),
(2, 'abcd', 'ap517', 9959927844, 2, '2023-12-07 13:52:18.577682', '2023-12-12 14:31:44.671337'),
(5, 'thriveni', 'ap2323', 9959927844, 2, '2023-12-06 19:19:57.788803', '2023-12-12 14:38:58.490728'),
(1, 'abcd', 'ap517', 9959927844, 2, '2023-12-16 14:49:15.583508', '2023-12-16 14:49:44.950692');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `id` int(100) NOT NULL,
  `user name` varchar(255) NOT NULL,
  `vehicle num` varchar(100) NOT NULL,
  `mobile num` bigint(11) NOT NULL,
  `vehicle type` int(100) NOT NULL,
  `entry` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`id`, `user name`, `vehicle num`, `mobile num`, `vehicle type`, `entry`) VALUES
(1, 'pramee', 'ap2323', 8198730990, 2, '2023-12-16 15:01:30.767824');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1235;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
