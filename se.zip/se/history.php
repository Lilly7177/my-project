<?php
            require 'connection.php';       //connecting to databases
            $sql ="SELECT * FROM  history";     //displaying data 
	    $result=mysqli_query($con,$sql);
?>
<html>
<head>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@600&display=swap" rel="stylesheet">
<title>
manage
</title>
<style>
	body{
		background: linear-gradient(45deg, #3498db, #2ecc71);

	}
    .styled-table{
        border-collapse:collapse;
        margin:25px 0;
        font-size:0.9em;
        min-width:1200px;
        box-shadow:0 0 20px rgba(0,0,0,0.15);
		background-color:white;
		font-family: 'Josefin Sans', sans-serif;
		


     }
     .styled-table thead tr {
        background-color:#6495ED;
        color:#ffffff;
        text-align:center;
		height:50px;
	
     }
     .styled-table th,.style-table td{
       padding: 12px 15px;
     }
     .styled-table tbody tr {
        border-bottom:1px solid #dddddd;
		height:45px;
     }
     .styled-table tbody tr:nth-of-type(even){
        color:blue;
        font-weight:bold
     }
     .styled-table tbody tr:last-of-type {
        border-bottom:2px solid #6495ED;
     }
     .container {
            color: white;
            background: #136a8a;
            background: 
            -webkit-linear-gradient(to right, #267871, #136a8a);
            background: 
            linear-gradient(to right, #267871, #136a8a);
            margin: auto;
            box-shadow: 
            0px 2px 10px rgba(0,0,0,0.2), 
            0px 10px 20px rgba(0,0,0,0.3), 
            0px 30px 60px 1px rgba(0,0,0,0.5);
            border-radius: 8px;
            padding: 5px;
			position:relative;
           }
           body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
           background-color:#D3D3D3;
           background-size:110% auto;
        }
        
        
      
</style>
     
<body>
<div class="continer">
<table class="styled-table" id="table">
<thead>
	<tr>
		<th>
		<b>USER NAME</b>
		</th>
		<th>
		<b>VEHICLE NUMBER</b>
		</th>
		<th>
		<b>MOBILE NUMBER</b>
		</th>
		<th>
		<b>VEHICLE TYPE</b>
		</th>
		<th>
		<b>ENTRY</b>
		</th>
		<th>
		<b>EXIT</b>
		</th>
	</tr>
</thead>
<tbody>
<?php while ($row = mysqli_fetch_assoc($result)) { ?>
	<tr>
		<td>
		<center>
		<?php 
		      echo $row['user name'];
		      ?>
		</center>
		</td>
		<td>
		<center>
		<?php
		 echo $row['vehicle num'];
		?>
		</center>
		</td>
		<td>
		<center>
		<?php
		 echo $row['mobile num'];
		?>
		</center>
		</td>
		<td>
		<center>
		<?php
		 echo $row['vehicle type'];
		 
		?>
		</center>
		</td> 
		<td>
		<center>
		<?php
		 echo $row['entry'];
		 ?>
		 </center>
		 </td>
		 <td>
		 <center>
		 
		<?php echo $row['exit'];} ?>
		 </center>
		 </td>
	</tr>
</tbody>
</table>
</div>
</body>
</html>






