<?php
//avalability of parking space
    $con=mysqli_connect('localhost','root','','se');
    $i=0;
?>
<html>
    <head>
        <style>
            body {
                display: flex;
                align-items: center;
                justify-content: center;
                background-color: #f4f4f4;
            }
            .box {
                width: 80px; /* Adjust as needed */
                height: 60px; /* Adjust as needed */
                border: 1px solid #010e16;
                box-sizing: border-box;
            }
            .container-grid {
                display: grid;
                grid-template-columns: repeat(5, 1fr); /* Adjust the number of columns as needed */
                grid-template-rows: repeat(5, 1fr); /* Adjust the number of rows as needed */
                gap: 20px; /* Adjust as needed */
                margin-top: 30px;
                margin-bottom: 30px;
                margin-left:15px;
                border-left:1.5px;
                padding-left:15px;
            }
            .header {
                background-color: #ffffff;
                border-radius: 5px;
                padding: 20px;
                display: flex;
                justify-content: space-between;
                width: 100%; /* Adjust the width as needed */
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
            }
            .vl {
                border-left: 6px solid grey;
                height: 1005px;
                position:left;
                left: 50%;
                margin-left: 5px;
                top:0;
            }
        </style>
    </head>
    <body>
        <div align="center">
            <h2>TWO WHEELERS</h2>
            <div class="container-grid" style="margin-right:33px">
                <?php
                    for($i=1;$i<=50;$i++){
                        $sql="SELECT * FROM `vehicle` WHERE id=$i"; 
                        $re=mysqli_query($con,$sql);
                        if(mysqli_num_rows($re)<1){
                            ?>
                            <button class="box" style="background:green"><?php  echo $i;  ?></button>    
                            <?php
                        }else{
                            ?>
                            <button class="box" style="background:red"><?php  echo $i;  ?></button>    
                            <?php
                        }
                    }
                ?>
            </div>
        </div>
        <br>
        <div class="vl"></div>
        <div align="center">
            <h2>FOUR WHEELERS</h2>
            <div class="container-grid" style="margin-right:33px">
                <?php
                    for($i=51;$i<=100;$i++){
                        $sql="SELECT * FROM `vehicle` WHERE id=$i"; 
                        $re=mysqli_query($con,$sql);
                        if(mysqli_num_rows($re)<1){
                            ?>
                            <button class="box" style="background:green"><?php  echo $i;  ?></button>    
                            <?php
                        }else{
                            ?>
                            <button class="box" style="background:red"><?php  echo $i;  ?></button>    
                            <?php
                        }
                    }
                ?>
            </div>
        </div>
    </body>
</html>

