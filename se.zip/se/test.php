<?php
include('smtp/PHPMailerAutoload.php');

// Function to generate a random OTP
function generateOTP() {
    $otpLength = 6; // You can adjust the length of the OTP as needed
    $otp = "";
    for ($i = 0; $i < $otpLength; $i++) {
        $otp .= rand(0, 9);
    }
    return $otp;
}

// Get the email from the form
$m = $_POST['email'];

// Generate a random OTP
$otp = generateOTP();

// Message with the OTP
$mess = "Your OTP is: $otp";

// Send the email with the OTP
echo smtp_mailer($m, 'Verification', $mess);

// Function to send email using PHPMailer
function smtp_mailer($to, $subject, $msg) {
    $mail = new PHPMailer(); 
    $mail->IsSMTP(); 
    $mail->SMTPAuth = true; 
    $mail->SMTPSecure = 'tls'; 
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 587; 
    $mail->IsHTML(true);
    $mail->CharSet = 'UTF-8';
    //$mail->SMTPDebug = 2; 
    $mail->Username = "veludutichinni@gmail.com";
    $mail->Password = "slmv lpwt lbsp ursx";
    $mail->SetFrom("veludutichinni@gmail.com");
    $mail->Subject = $subject;
    $mail->Body = $msg;
    $mail->AddAddress($to);
    $mail->SMTPOptions = array('ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => false
    ));
    
    if (!$mail->Send()) {
        echo $mail->ErrorInfo;
    } else {
       
    }
}
?>
