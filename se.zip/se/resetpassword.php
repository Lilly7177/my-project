<?php
include('smtp/PHPMailerAutoload.php');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "register";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Get the token from the URL
    $token = $_GET['token'];

    // Check if the token is valid and not expired
    $query = "SELECT * FROM users WHERE token = '$token' AND password_reset_time >= NOW() - INTERVAL 1 HOUR";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // Token is valid, allow the user to reset the password
        $row = mysqli_fetch_assoc($result);
        $email = $row['email'];
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <!-- Include your CSS and Bootstrap links here -->
        </head>
        <body>
            <section>
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 offset-md-3">
                            <h2>Reset Password</h2>

                            <form action="updatepassword.php" method="post">
                                <input type="hidden" name="email" value="<?php echo $email; ?>">
                                <div class="form-group">
                                    <label for="new_password">New Password:</label>
                                    <input type="password" class="form-control" id="new_password" name="new_password" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Reset Password</button>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        </body>
        </html>
        <?php
    } else {
        // Token is invalid or expired
        echo 'Invalid or expired token. Please try again.';
    }
}
?>
