<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "register";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $newPassword = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    // Update the user's password in the database
    $query = "UPDATE users SET password = '$newPassword', token = NULL, password_reset_time = NULL WHERE email = '$email'";
    mysqli_query($conn, $query);

    echo 'Password updated successfully. You can now <a href="login.html">login</a> with your new password.';
}
?>
