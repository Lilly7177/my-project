<?php
include('smtp/PHPMailerAutoload.php');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "register";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    // Generate a unique token or code
    $token = bin2hex(random_bytes(16));

    // Store the token in the database along with the user's email
    // You need to have a users table in your database with columns: id, email, token, and password_reset_time
    $query = "UPDATE users SET token = '$token', password_reset_time = NOW() WHERE email = '$email'";
    mysqli_query($conn, $query);

    // Send the password reset email with the token
    $subject = 'Password Reset';
    $msg = "To reset your password, click the following link: http://localhost:81/Wt/se/resetpassword.php?token=$token";
    $result = smtp_mailer($email, $subject, $msg);

    if ($result === 'Sent') {
        echo 'Password reset instructions sent to your email.';
    } else {
        echo 'Error sending email. Please try again later.';
    }
}

function smtp_mailer($to, $subject, $msg) {
    // Implement your email sending logic here using PHPMailer
    // This function should handle the email sending using the provided parameters
    // Ensure that PHPMailer is properly configured in your project
    // You can refer to PHPMailer documentation for more details
    $mail = new PHPMailer(); 
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'tls'; 
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 587; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	//$mail->SMTPDebug = 2; 
	$mail->Username = "veludutichinni@gmail.com";
	$mail->Password = "slmv lpwt lbsp ursx";
	$mail->SetFrom("veludutichinni@gmail.com");
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddAddress($to);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){
		echo $mail->ErrorInfo;
	}else{
		return 'Sent';
	}

}
?>
