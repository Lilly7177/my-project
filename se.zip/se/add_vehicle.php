<?php

if($_SERVER['REQUEST_METHOD']=='POST'){
		$con=mysqli_connect('localhost','root','','se');
               $uname= $_POST['UserName'];
		$vnum= $_POST['VehicleNum'];
		$mnum= $_POST['MobileNum'];
		$vtype= $_POST['VehicleType'];
		$i=0;
		if($vtype==2){
			for($i=1;$i<17;$i++){
				$sql="SELECT * FROM `vehicle` WHERE id=$i";
				$re=mysqli_query($con,$sql);
				if(mysqli_num_rows($re)<1){
					$sql ="INSERT INTO `vehicle`(`id`,`user name`, `vehicle num`, `mobile num`, `vehicle type`) VALUES 			
					  ($i,'$uname','$vnum','$mnum','$vtype')";    
		       		 mysqli_query($con,$sql);
		       		 break;
				}
			}
			if($i==17)
			{
			  echo "<script>alert('no slots') </script>";
			 }
		 }else{
		 	for($i=17;$i<=32;$i++){
				$sql="SELECT * FROM `vehicle` WHERE id=$i";
				$re=mysqli_query($con,$sql);
				if(mysqli_num_rows($re)<1){
					$sql ="INSERT INTO `vehicle`(`id`,`user name`, `vehicle num`, `mobile num`, `vehicle type`) VALUES 			
					  ($i,'$uname','$vnum','$mnum','$vtype')";    
		       		 mysqli_query($con,$sql);
		       		 break;
				}
			}
			if($i==33)
			{
			  echo "<script>alert('no slots') </script>";
			 }
		 }
}
		
?>
<!DOCTYPE html>
<html>
<head>
    <title>Vehicle Managment System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="add.css">
     
</head>

<body>
<div class="login-container">
<center>
    <h1>Add Vehicle</h1>
    <form  method="POST" name="RegForm" onsubmit="return formValidator();" action="<?php echo $_SERVER['PHP_SELF'];?>">
       <table cellpadding='3' cellspacing='0.5'> 
        <tr>
        <td>
        <i class="fas fa-user"></i></td>
        <td><input type="text" class="login__input" placeholder="User Name" id="UserName" name="UserName" ></td>
        </tr>
        <tr>
        <td>
        <i class="fas fa-car-side"></i></td>
        <td>
        <label for="Vehicle Num"></label>
<input type="text"class="login__input" placeholder="Vehicle Num" id="VehicleNum" name="VehicleNum" ></td>
        </tr>
        <tr><td>
        <i class="fas fa-mobile"></i></td>
       <td> <input type="text" class="login__input" placeholder="Mobile Num" id="MobileNum" name="MobileNum" pattern="[0-9]{10}"></td>
        </tr>
        <tr>
         <td>
        <i class="fas fa-car"></i>
        </td>
        <td>
         <input type="text" class="login__input" placeholder="Vehicle type"  id="VehicleType" name="VehicleType" pattern="[2|4]{1}">
         </td>
        </tr>
        <tr>
        <td>
        <input type="submit" value="Submit">
        </td>
        </tr>
            
    </form>
   </center>
  </div>
</body>
</html>
